# project: Automatic backUp in mongo using AWS
## Purpose
Create cronjob will use a script to create a backup of database in mongo and automatic store it in S3.

## Tech Tool
- AWS
- MongoDB
- Bash script
- Cronjob in linux 

## Diagram

working ....
